export const initialJobs = [
  {
    id: 1,
    title: "Frontend Developer",
    location: "Pune, India",
    type: "Full Time",
    experience: "1–3 Years",
    description:
      "We are looking for a React developer with strong UI skills.",
  },
];

